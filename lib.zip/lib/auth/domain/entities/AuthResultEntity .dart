import 'package:graduation_project/auth/domain/entities/RegisterResponseEntity%20.dart';

class AuthResultEntity {
  RegisterResponseEntity? registerResponseEntity;
  AuthResultEntity({this.registerResponseEntity});
}
